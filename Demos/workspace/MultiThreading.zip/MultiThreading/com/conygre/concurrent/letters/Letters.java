package com.conygre.concurrent.letters;

public interface Letters {
	void addLetter(char c);
	char takeLetter();

}
